function acessoAoSite() {
    console.log("Bem vindo ao site")
    
}
acessoAoSite();
//preguiça de fazer em html xD