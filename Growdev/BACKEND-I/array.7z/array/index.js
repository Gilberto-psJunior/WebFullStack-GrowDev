let frutas=["tomate","maça","abacate"];
frutas.push("pera");
frutas.pop()
frutas.unshift("limao")
frutas.shift()
console.log(frutas);